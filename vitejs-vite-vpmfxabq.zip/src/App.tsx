import React from 'react';
import LoveStory from './LoveStory';

export default function App() {
  return <LoveStory />;
}
